import { motion } from 'motion/react';
import { testimonials } from '../data';
import { Star, Quote } from 'lucide-react';

export function Testimonials() {
  return (
    <section className="py-32 bg-cream dark:bg-charcoal relative overflow-hidden">
      {/* Abstract blurred background shapes */}
      <div className="absolute -left-40 top-40 w-[600px] h-[600px] bg-rosegold/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute right-0 bottom-0 w-[600px] h-[600px] bg-rosegold/5 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-24">
          <span className="text-rosegold-dark dark:text-rosegold font-medium tracking-[0.3em] uppercase text-xs mb-6 block">
            Client Stories
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-dark dark:text-cream mb-8">Loved by Our Clients</h2>
          <div className="w-24 h-[1px] bg-rosegold mx-auto" />
        </div>

        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.8, delay: index * 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="glass p-10 md:p-14 rounded-[3rem] relative group hover:-translate-y-4 transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
            >
              <Quote className="absolute top-12 right-12 text-rosegold/10 dark:text-cream/5 w-20 h-20 transform group-hover:scale-110 group-hover:text-rosegold/20 transition-all duration-700" />
              <div className="flex gap-1.5 mb-8 relative z-10">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={16} className="fill-gold text-gold drop-shadow-sm" />
                ))}
              </div>
              <p className="text-dark/80 dark:text-cream/80 text-lg md:text-xl italic mb-12 leading-relaxed font-light relative z-10">
                "{testimonial.text}"
              </p>
              <div className="flex items-center gap-6 relative z-10">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-rosegold-light to-rosegold-dark flex items-center justify-center text-white font-serif font-medium text-xl shadow-lg">
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-serif text-lg tracking-wide text-dark dark:text-cream">{testimonial.name}</h4>
                  <p className="text-[10px] text-dark/40 dark:text-cream/40 tracking-[0.2em] uppercase mt-2">Verified Client</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
