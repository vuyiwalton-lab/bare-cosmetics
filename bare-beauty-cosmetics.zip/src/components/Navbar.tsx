import { ShoppingBag, Search, Menu, X, Moon, Sun } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  onCartOpen: () => void;
  cartItemCount: number;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export function Navbar({ onCartOpen, cartItemCount, isDarkMode, toggleDarkMode }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Shop', href: '#shop' },
    { name: 'Collections', href: '#categories' },
    { name: 'Story', href: '#about' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? 'bg-white/80 dark:bg-charcoal/80 backdrop-blur-xl shadow-[0_4px_30px_rgba(0,0,0,0.05)] py-4' : 'bg-transparent py-8'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`p-2 transition-colors ${isScrolled ? 'text-dark dark:text-cream' : 'text-dark dark:text-cream'} hover:text-rosegold`}
            >
              {isMobileMenuOpen ? <X size={24} strokeWidth={1.5} /> : <Menu size={24} strokeWidth={1.5} />}
            </button>
          </div>

          {/* Logo */}
          <div className="flex-shrink-0 flex items-center justify-center lg:justify-start">
            <a href="#" className={`font-serif text-2xl md:text-3xl tracking-[0.2em] font-medium ${isScrolled ? 'text-dark dark:text-cream' : 'text-dark dark:text-cream'}`}>
              BARE BEAUTY
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex space-x-10">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`relative text-xs font-medium tracking-[0.15em] uppercase transition-colors group ${
                  isScrolled ? 'text-dark/80 dark:text-cream/80' : 'text-dark dark:text-cream/90'
                } hover:text-rosegold`}
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-rosegold transition-all duration-300 ease-out group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-5 lg:space-x-8">
            <button className={`${isScrolled ? 'text-dark/80 dark:text-cream/80' : 'text-dark dark:text-cream/90'} hover:text-rosegold transition-colors`}>
              <Search size={20} strokeWidth={1.5} />
            </button>
            <button 
              onClick={toggleDarkMode}
              className={`${isScrolled ? 'text-dark/80 dark:text-cream/80' : 'text-dark dark:text-cream/90'} hover:text-rosegold transition-colors`}
            >
              {isDarkMode ? <Sun size={20} strokeWidth={1.5} /> : <Moon size={20} strokeWidth={1.5} />}
            </button>
            <button
              onClick={onCartOpen}
              className={`${isScrolled ? 'text-dark/80 dark:text-cream/80' : 'text-dark dark:text-cream/90'} hover:text-rosegold transition-colors relative`}
            >
              <ShoppingBag size={20} strokeWidth={1.5} />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-rosegold text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center shadow-lg">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden glass border-t border-gray-100 dark:border-white/10"
          >
            <div className="px-4 py-8 space-y-6 text-center">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block text-lg font-serif tracking-widest text-dark hover:text-rosegold dark:text-cream"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
