import { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Mail } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    message: ''
  });

  const handleWhatsApp = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const text = `Hello Bare Beauty, my name is ${formData.firstName} ${formData.lastName}.%0A%0AEmail: ${formData.email}%0A%0AMessage: ${formData.message}`;
    window.open(`https://wa.me/263779525675?text=${text}`, '_blank');
  };

  return (
    <section id="contact" className="relative bg-white dark:bg-dark">
      <div className="grid lg:grid-cols-2 min-h-[800px]">
        
        {/* Image Section */}
        <div className="relative hidden lg:block h-full">
          <img 
            src="https://images.unsplash.com/photo-1596462502278-27bf85033e5a?auto=format&fit=crop&q=80&w=1200" 
            alt="Luxury Cosmetics" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-dark/20" />
        </div>

        {/* Content Section */}
        <div className="py-24 px-4 sm:px-6 lg:px-16 xl:px-24 flex items-center bg-cream dark:bg-charcoal relative overflow-hidden">
          {/* Subtle glow */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-rosegold/5 rounded-full blur-[100px] pointer-events-none" />
          
          <div className="w-full max-w-2xl mx-auto lg:mx-0 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            >
              <span className="text-rosegold-dark dark:text-rosegold font-medium tracking-[0.3em] uppercase text-[10px] mb-6 block">
                Consultation
              </span>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-dark dark:text-cream mb-8">Get in Touch</h2>
              <div className="w-16 h-[1px] bg-rosegold mb-12" />
              
              <form className="space-y-8 mb-16">
                <div className="grid sm:grid-cols-2 gap-8">
                  <div className="relative group">
                    <input type="text" id="name" value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} className="peer w-full bg-transparent border-b border-dark/20 dark:border-cream/20 py-3 text-dark dark:text-cream focus:outline-none focus:border-rosegold transition-colors placeholder-transparent text-sm font-light" placeholder="First Name" />
                    <label htmlFor="name" className="absolute left-0 -top-3.5 text-xs tracking-widest uppercase text-dark/40 dark:text-cream/40 transition-all peer-placeholder-shown:text-sm peer-placeholder-shown:tracking-normal peer-placeholder-shown:normal-case peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-[10px] peer-focus:tracking-widest peer-focus:uppercase peer-focus:text-rosegold">First Name</label>
                  </div>
                  <div className="relative group">
                    <input type="text" id="lastName" value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} className="peer w-full bg-transparent border-b border-dark/20 dark:border-cream/20 py-3 text-dark dark:text-cream focus:outline-none focus:border-rosegold transition-colors placeholder-transparent text-sm font-light" placeholder="Last Name" />
                    <label htmlFor="lastName" className="absolute left-0 -top-3.5 text-xs tracking-widest uppercase text-dark/40 dark:text-cream/40 transition-all peer-placeholder-shown:text-sm peer-placeholder-shown:tracking-normal peer-placeholder-shown:normal-case peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-[10px] peer-focus:tracking-widest peer-focus:uppercase peer-focus:text-rosegold">Last Name</label>
                  </div>
                </div>
                <div className="relative group">
                  <input type="email" id="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="peer w-full bg-transparent border-b border-dark/20 dark:border-cream/20 py-3 text-dark dark:text-cream focus:outline-none focus:border-rosegold transition-colors placeholder-transparent text-sm font-light" placeholder="Email Address" />
                  <label htmlFor="email" className="absolute left-0 -top-3.5 text-xs tracking-widest uppercase text-dark/40 dark:text-cream/40 transition-all peer-placeholder-shown:text-sm peer-placeholder-shown:tracking-normal peer-placeholder-shown:normal-case peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-[10px] peer-focus:tracking-widest peer-focus:uppercase peer-focus:text-rosegold">Email Address</label>
                </div>
                <div className="relative group">
                  <textarea id="message" value={formData.message} onChange={e => setFormData({...formData, message: e.target.value})} rows={3} className="peer w-full bg-transparent border-b border-dark/20 dark:border-cream/20 py-3 text-dark dark:text-cream focus:outline-none focus:border-rosegold transition-colors placeholder-transparent resize-none text-sm font-light" placeholder="Message"></textarea>
                  <label htmlFor="message" className="absolute left-0 -top-3.5 text-xs tracking-widest uppercase text-dark/40 dark:text-cream/40 transition-all peer-placeholder-shown:text-sm peer-placeholder-shown:tracking-normal peer-placeholder-shown:normal-case peer-placeholder-shown:top-3 peer-focus:-top-3.5 peer-focus:text-[10px] peer-focus:tracking-widest peer-focus:uppercase peer-focus:text-rosegold">How can we assist you?</label>
                </div>
                <a href="#" onClick={handleWhatsApp} className="btn-premium block text-center w-full py-5 bg-dark text-white hover:text-dark transition-all duration-300 tracking-[0.2em] uppercase text-xs shadow-xl dark:bg-cream dark:text-charcoal dark:hover:text-cream">
                  <span className="relative z-10">Send via WhatsApp</span>
                  <div className="absolute inset-0 h-full w-full bg-rosegold scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500 ease-out -z-10" />
                </a>
              </form>

              <div className="grid grid-cols-2 gap-8 border-t border-dark/10 dark:border-cream/10 pt-12">
                <div>
                  <div className="flex items-center gap-3 mb-4 text-rosegold">
                    <MapPin size={18} strokeWidth={1.5} />
                    <span className="font-serif text-lg text-dark dark:text-cream">Boutique</span>
                  </div>
                  <p className="text-dark/60 dark:text-cream/60 font-light text-sm leading-relaxed">
                    Suite 4B, Dansquare Building<br />
                    Corner 4th & 5th Avenue<br />
                    Bulawayo, Zimbabwe
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-4 text-rosegold">
                    <Clock size={18} strokeWidth={1.5} />
                    <span className="font-serif text-lg text-dark dark:text-cream">Hours</span>
                  </div>
                  <p className="text-dark/60 dark:text-cream/60 font-light text-sm leading-relaxed">
                    Mon - Fri: 8am - 5pm<br />
                    Sat: 8am - 4pm<br />
                    Sun: 8am - 5pm
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-4 text-rosegold">
                    <Phone size={18} strokeWidth={1.5} />
                    <span className="font-serif text-lg text-dark dark:text-cream">Phone</span>
                  </div>
                  <p className="text-dark/60 dark:text-cream/60 font-light text-sm leading-relaxed">
                    +263 77 952 5675
                  </p>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-4 text-rosegold">
                    <Mail size={18} strokeWidth={1.5} />
                    <span className="font-serif text-lg text-dark dark:text-cream">Email</span>
                  </div>
                  <p className="text-dark/60 dark:text-cream/60 font-light text-sm leading-relaxed">
                    info@barebeauty.co.zw
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
