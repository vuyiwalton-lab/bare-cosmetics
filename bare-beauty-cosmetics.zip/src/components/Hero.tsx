import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';

export function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0]);

  // Generate particles
  const particles = Array.from({ length: 15 }).map((_, i) => ({
    id: i,
    size: Math.random() * 6 + 2,
    left: `${Math.random() * 100}%`,
    animationDuration: `${Math.random() * 10 + 10}s`,
    animationDelay: `${Math.random() * 5}s`,
  }));

  return (
    <section ref={ref} className="relative h-screen flex items-center overflow-hidden bg-black">
      {/* Particles */}
      <div className="absolute inset-0 z-10 overflow-hidden pointer-events-none">
        {particles.map((p) => (
          <div
            key={p.id}
            className="particle"
            style={{
              width: p.size,
              height: p.size,
              left: p.left,
              bottom: '-20px',
              animationDuration: p.animationDuration,
              animationDelay: p.animationDelay,
            }}
          />
        ))}
      </div>

      {/* Parallax Background */}
      <motion.div 
        style={{ y, opacity }}
        className="absolute inset-0 z-0"
      >
        <img
          src="https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&q=80&w=2000"
          alt="Luxury Cosmetics Model"
          className="w-full h-full object-cover object-center opacity-80"
        />
        {/* Soft luxury gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/60 to-transparent dark:from-charcoal/95 dark:via-charcoal/60 dark:to-transparent" />
      </motion.div>

      {/* Floating Products Decoration */}
      <motion.div
        animate={{ y: [-20, 20, -20], rotate: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
        className="absolute top-1/4 right-[10%] w-32 md:w-56 hidden lg:block z-10"
      >
         <img src="https://images.unsplash.com/photo-1596462502278-27bf85033e5a?auto=format&fit=crop&q=80&w=400" alt="Cosmetic Product" className="rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] object-cover h-80" />
      </motion.div>
      
      <motion.div
        animate={{ y: [20, -20, 20], rotate: [0, -8, 0] }}
        transition={{ repeat: Infinity, duration: 10, ease: "easeInOut", delay: 1 }}
        className="absolute bottom-1/4 right-[25%] w-24 md:w-48 hidden lg:block z-10"
      >
         <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400" alt="Cosmetic Product" className="rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] object-cover h-64" />
      </motion.div>

      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-2xl glass p-8 md:p-14 rounded-3xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
          >
            <div className="flex items-center gap-4 mb-8">
               <div className="w-16 h-[1px] bg-rosegold" />
               <span className="text-rosegold-dark dark:text-rosegold-light font-medium tracking-[0.3em] uppercase text-xs md:text-sm">
                 Bare Beauty
               </span>
            </div>
            <h1 className="text-5xl md:text-7xl lg:text-[5rem] font-serif text-dark mb-8 leading-[1.05] dark:text-cream">
              Reveal Your <br />
              <span className="italic text-gradient relative inline-block">
                Natural Beauty.
                <motion.span 
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ delay: 1.2, duration: 1, ease: "easeOut" }}
                  className="absolute -bottom-2 left-0 h-[2px] bg-gradient-to-r from-rosegold to-transparent" 
                />
              </span>
            </h1>
            <p className="text-lg md:text-xl text-dark/80 mb-12 max-w-lg dark:text-cream/80 font-light leading-relaxed">
              Premium Beauty Products, Skincare, Makeup and Hair Care curated for the elegant women of Bulawayo.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6">
              <a
                href="#shop"
                className="btn-premium group relative inline-flex items-center justify-center px-10 py-5 text-xs font-medium tracking-[0.2em] text-white bg-dark hover:text-dark transition-all rounded-full overflow-hidden uppercase dark:bg-cream dark:text-charcoal dark:hover:text-cream"
              >
                <span className="relative z-10">Shop Collection</span>
                <div className="absolute inset-0 h-full w-full bg-rosegold scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500 ease-out" />
              </a>
              <a
                href="https://wa.me/263779525675"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-10 py-5 text-xs font-medium tracking-[0.2em] text-dark border border-dark/20 hover:border-dark hover:bg-dark hover:text-white transition-all rounded-full uppercase dark:text-cream dark:border-cream/30 dark:hover:bg-cream dark:hover:text-charcoal"
              >
                WhatsApp Us
              </a>
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Elegant Scroll Indicator */}
      <motion.div 
        className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex flex-col items-center z-20 cursor-pointer"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
        onClick={() => document.getElementById('categories')?.scrollIntoView({ behavior: 'smooth' })}
      >
        <span className="text-[10px] tracking-[0.3em] uppercase mb-4 text-dark/50 dark:text-cream/50">Scroll</span>
        <div className="w-[1px] h-16 bg-gradient-to-b from-dark/40 to-transparent dark:from-cream/40" />
      </motion.div>
    </section>
  );
}
