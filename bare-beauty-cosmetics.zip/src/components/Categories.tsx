import { motion } from 'motion/react';
import { categories } from '../data';
import * as Icons from 'lucide-react';

export function Categories() {
  return (
    <section id="categories" className="py-32 bg-white dark:bg-dark relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-rosegold/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-24">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-rosegold-dark dark:text-rosegold font-medium tracking-[0.3em] uppercase text-xs mb-6 block"
          >
            The Collection
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-serif text-dark dark:text-cream mb-8"
          >
            Shop by Category
          </motion.h2>
          <motion.div 
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="w-24 h-[1px] bg-rosegold mx-auto" 
          />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 sm:gap-8 lg:gap-12">
          {categories.map((category, index) => {
            const IconComponent = (Icons as any)[category.icon];
            
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.8, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
                className="group cursor-pointer flex flex-col items-center"
              >
                <div className="relative w-full aspect-[3/4] overflow-hidden rounded-full mb-8 bg-cream shadow-sm">
                  <img
                    src={category.image}
                    alt={category.name}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-[1.5s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-dark/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] transform translate-y-8 group-hover:translate-y-0">
                    <div className="w-16 h-16 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-dark shadow-xl">
                      {IconComponent && <IconComponent size={24} strokeWidth={1.2} />}
                    </div>
                  </div>
                </div>
                <h3 className="text-center font-serif text-lg md:text-xl tracking-wide text-dark dark:text-cream group-hover:text-rosegold transition-colors">
                  {category.name}
                </h3>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
