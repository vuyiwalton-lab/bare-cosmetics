import { Instagram, Facebook, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-charcoal text-white pt-24 pb-12 border-t border-white/5 relative overflow-hidden">
      {/* Subtle luxury glow in footer */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-px bg-gradient-to-r from-transparent via-rosegold/30 to-transparent" />
      
      <div className="max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-16 lg:gap-8 mb-24">
          
          <div className="lg:col-span-4 space-y-8">
            <h3 className="font-serif text-3xl tracking-[0.2em] text-white font-medium">BARE BEAUTY</h3>
            <p className="text-white/60 text-sm leading-relaxed max-w-sm font-light">
              Premium Beauty Products, Skincare, Makeup and Hair Care. Reveal your natural elegance with our curated collections.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-rosegold hover:border-rosegold hover:text-white transition-all duration-300">
                <Instagram size={18} strokeWidth={1.5} />
              </a>
              <a href="#" className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-rosegold hover:border-rosegold hover:text-white transition-all duration-300">
                <Facebook size={18} strokeWidth={1.5} />
              </a>
              <a href="#" className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-rosegold hover:border-rosegold hover:text-white transition-all duration-300">
                <Twitter size={18} strokeWidth={1.5} />
              </a>
            </div>
          </div>

          <div className="lg:col-span-2 lg:col-start-6">
            <h4 className="font-sans text-xs tracking-[0.2em] uppercase mb-8 text-white">Quick Links</h4>
            <ul className="space-y-4 text-sm text-white/60 font-light">
              <li><a href="#" className="hover:text-rosegold transition-colors">Home</a></li>
              <li><a href="#shop" className="hover:text-rosegold transition-colors">The Collection</a></li>
              <li><a href="#about" className="hover:text-rosegold transition-colors">Our Heritage</a></li>
              <li><a href="#contact" className="hover:text-rosegold transition-colors">Contact Boutique</a></li>
              <li><a href="#" className="hover:text-rosegold transition-colors">FAQ</a></li>
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h4 className="font-sans text-xs tracking-[0.2em] uppercase mb-8 text-white">Client Care</h4>
            <ul className="space-y-4 text-sm text-white/60 font-light">
              <li><a href="#" className="hover:text-rosegold transition-colors">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-rosegold transition-colors">Track Order</a></li>
              <li><a href="#" className="hover:text-rosegold transition-colors">Wholesale</a></li>
              <li><a href="#" className="hover:text-rosegold transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-rosegold transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div className="lg:col-span-3">
            <h4 className="font-sans text-xs tracking-[0.2em] uppercase mb-8 text-white">Newsletter</h4>
            <p className="text-white/60 text-sm mb-6 font-light leading-relaxed">Join our list for exclusive beauty insights and early access to new collections.</p>
            <form className="space-y-4 group">
              <div className="relative">
                <input 
                  type="email" 
                  placeholder="Email Address" 
                  className="w-full bg-transparent border-b border-white/20 px-0 py-3 text-sm text-white focus:outline-none focus:border-rosegold transition-colors placeholder-white/30 font-light"
                />
              </div>
              <button 
                type="button" 
                className="w-full bg-white text-dark rounded-full px-4 py-4 text-[10px] font-medium hover:bg-rosegold hover:text-white transition-colors uppercase tracking-[0.2em] mt-4"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-white/40 text-xs font-light tracking-wide">
            &copy; {new Date().getFullYear()} Bare Beauty Cosmetics. All rights reserved.
          </p>
          <div className="flex gap-4 opacity-50">
             <div className="text-[10px] tracking-[0.2em] uppercase font-light">Visa</div>
             <div className="text-white/20">•</div>
             <div className="text-[10px] tracking-[0.2em] uppercase font-light">Mastercard</div>
             <div className="text-white/20">•</div>
             <div className="text-[10px] tracking-[0.2em] uppercase font-light">Cash</div>
          </div>
        </div>
      </div>
    </footer>
  );
}
