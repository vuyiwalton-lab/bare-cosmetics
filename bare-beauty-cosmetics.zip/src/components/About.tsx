import { motion } from 'motion/react';

export function About() {
  return (
    <section id="about" className="py-32 bg-white dark:bg-dark relative overflow-hidden">
      {/* Decorative element */}
      <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-rosegold/5 rounded-full blur-[100px] -ml-32 -mt-32 dark:bg-white/5 pointer-events-none" />
      
      <div className="max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <div className="aspect-[3/4] rounded-t-full rounded-b-[3rem] overflow-hidden shadow-2xl relative">
              <img
                src="https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&q=80&w=1000"
                alt="Bare Beauty Cosmetics Store"
                className="w-full h-full object-cover transition-transform duration-[2s] hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark/30 to-transparent" />
            </div>
            {/* Floating Image */}
            <div className="absolute -bottom-12 -right-8 w-2/3 aspect-square rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.15)] border-8 border-white dark:border-dark hidden sm:block">
              <img
                src="https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&q=80&w=800"
                alt="Cosmetics application"
                className="w-full h-full object-cover transition-transform duration-[2s] hover:scale-105"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:pl-12"
          >
            <span className="text-[10px] font-medium tracking-[0.3em] uppercase text-rosegold-dark dark:text-rosegold mb-6 block">The Heritage</span>
            <h3 className="text-4xl md:text-5xl lg:text-6xl font-serif text-dark dark:text-cream mb-8 leading-[1.1]">
              Elegance & Care in the Heart of Bulawayo
            </h3>
            <div className="w-24 h-[1px] bg-rosegold mb-10" />
            
            <div className="space-y-6 text-dark/70 dark:text-cream/70 text-lg md:text-xl font-light leading-relaxed">
              <p>
                Bare Beauty Cosmetics is the premier destination for luxury beauty products, skincare, makeup, beauty accessories, and hair care. 
              </p>
              <p>
                We believe that every individual deserves to feel confident and beautiful. Our mission is to supply high-quality, authentic products from internationally recognized brands alongside carefully curated local favorites.
              </p>
              <p>
                Whether you are a beauty professional looking for wholesale supplies or a cosmetic lover seeking the perfect shade, our friendly team is dedicated to providing exceptional service and affordable prices in a welcoming environment.
              </p>
            </div>

            <div className="mt-12">
              <a href="#contact" className="inline-flex items-center gap-3 text-dark dark:text-cream text-xs font-medium uppercase tracking-[0.2em] border-b border-dark/20 dark:border-cream/20 pb-2 hover:text-rosegold hover:border-rosegold transition-all">
                Visit Our Boutique
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
