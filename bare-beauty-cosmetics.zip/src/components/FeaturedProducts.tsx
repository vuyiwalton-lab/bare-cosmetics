import { motion } from 'motion/react';
import { products } from '../data';
import { Product } from '../types';
import { ShoppingBag, Eye, Heart, Star } from 'lucide-react';

interface FeaturedProductsProps {
  onAddToCart: (product: Product) => void;
}

export function FeaturedProducts({ onAddToCart }: FeaturedProductsProps) {
  return (
    <section id="shop" className="py-32 bg-cream dark:bg-charcoal">
      <div className="max-w-[90rem] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-6">
          <div className="max-w-2xl">
            <span className="text-rosegold-dark dark:text-rosegold font-medium tracking-[0.2em] uppercase text-xs mb-4 block">
              Curated For You
            </span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-dark dark:text-cream mb-6">Trending Now</h2>
            <p className="text-dark/60 dark:text-cream/60 font-light max-w-lg">Discover our most sought-after products, designed to elevate your daily ritual.</p>
          </div>
          <a href="#" className="inline-flex items-center gap-3 text-xs font-medium tracking-[0.2em] text-dark hover:text-rosegold uppercase pb-2 border-b border-dark/20 hover:border-rosegold transition-all dark:text-cream dark:border-cream/20">
            View All Collection
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-16">
          {products.slice(0, 8).map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="group flex flex-col relative"
            >
              {/* Luxury Frame Behind Image */}
              <div className="absolute inset-0 bg-gradient-to-tr from-rosegold/5 to-transparent dark:from-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700 rounded-[2rem] -z-10 transform scale-95 group-hover:scale-105" />

              {/* Product Image */}
              <div className="relative aspect-[3/4] bg-white dark:bg-dark rounded-[2rem] overflow-hidden mb-8 shadow-sm group-hover:shadow-[0_20px_40px_rgba(0,0,0,0.08)] transition-all duration-700 p-2">
                <div className="w-full h-full rounded-[1.5rem] overflow-hidden relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-[1.5s] ease-[cubic-bezier(0.16,1,0.3,1)]"
                  />
                  
                  {/* Subtle glass overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-dark/40 via-transparent to-dark/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                  
                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {product.isNew && (
                      <span className="bg-white/90 backdrop-blur-md text-dark text-[9px] uppercase tracking-[0.2em] px-4 py-2 rounded-full font-medium shadow-sm">
                        New Arrival
                      </span>
                    )}
                    {product.isSale && (
                      <span className="bg-rosegold/90 backdrop-blur-md text-white text-[9px] uppercase tracking-[0.2em] px-4 py-2 rounded-full font-medium shadow-sm">
                        Private Sale
                      </span>
                    )}
                  </div>

                  {/* Wishlist Button */}
                  <button 
                    className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/50 backdrop-blur-md flex items-center justify-center text-dark hover:text-white hover:bg-rosegold transition-all duration-500 opacity-0 group-hover:opacity-100 translate-x-4 group-hover:translate-x-0"
                    title="Add to Wishlist"
                  >
                    <Heart size={16} strokeWidth={1.5} />
                  </button>

                  {/* Hover Actions */}
                  <div className="absolute bottom-6 left-0 right-0 flex justify-center items-center gap-3 opacity-0 group-hover:opacity-100 transform translate-y-8 group-hover:translate-y-0 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] px-6">
                    <button 
                      onClick={() => onAddToCart(product)}
                      className="flex-1 flex items-center justify-center gap-2 px-6 py-4 rounded-full bg-white text-dark hover:bg-dark hover:text-white dark:bg-dark dark:text-cream dark:hover:bg-cream dark:hover:text-dark transition-all duration-300 text-[10px] font-medium tracking-[0.2em] uppercase shadow-lg"
                    >
                      <ShoppingBag size={14} />
                      Add to Bag
                    </button>
                    <button 
                      className="w-12 h-12 rounded-full bg-white/90 backdrop-blur-md text-dark hover:bg-white flex items-center justify-center shadow-lg transition-colors shrink-0"
                      title="Quick View"
                    >
                      <Eye size={16} strokeWidth={1.5} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Product Info */}
              <div className="text-center px-4">
                <p className="text-[10px] text-dark/40 dark:text-cream/40 uppercase tracking-[0.3em] mb-3">{product.category}</p>
                <h3 className="font-serif text-lg md:text-xl text-dark dark:text-cream mb-4 group-hover:text-rosegold transition-colors">
                  {product.name}
                </h3>
                
                <div className="flex flex-col items-center gap-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={12} 
                        className={i < Math.floor(product.rating) ? "fill-gold text-gold" : "text-gray-200 dark:text-gray-700"} 
                      />
                    ))}
                    <span className="text-[10px] text-dark/40 dark:text-cream/40 ml-2 tracking-widest">({product.reviews})</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-dark dark:text-cream font-medium tracking-wide">${product.price.toFixed(2)}</span>
                    {product.originalPrice && (
                      <span className="text-dark/40 dark:text-cream/40 line-through text-sm tracking-wide">${product.originalPrice.toFixed(2)}</span>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
