import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
}

export function CartSidebar({ isOpen, onClose, cart, onUpdateQuantity, onRemoveItem }: CartSidebarProps) {
  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[60]"
          />

          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white dark:bg-dark shadow-2xl z-[70] flex flex-col"
          >
            {/* Header */}
            <div className="px-6 py-6 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingBag className="text-rosegold" />
                <h2 className="text-xl font-serif text-dark dark:text-lightbg">Your Cart</h2>
                <span className="bg-softpink text-rosegold-dark px-2 py-0.5 rounded-full text-xs font-bold">
                  {cart.length}
                </span>
              </div>
              <button 
                onClick={onClose}
                className="p-2 text-gray-400 hover:text-dark dark:hover:text-lightbg transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-6">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
                  <ShoppingBag size={64} className="text-gray-300 dark:text-gray-600" />
                  <p className="text-lg text-dark dark:text-lightbg">Your cart is currently empty.</p>
                  <button 
                    onClick={onClose}
                    className="text-rosegold hover:underline"
                  >
                    Continue Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {cart.map((item) => (
                    <div key={item.id} className="flex gap-4 group">
                      <div className="w-20 h-24 rounded-lg overflow-hidden shrink-0 bg-gray-100">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 flex flex-col justify-between py-1">
                        <div className="flex justify-between items-start gap-2">
                          <div>
                            <p className="text-xs text-dark/50 dark:text-lightbg/50 uppercase tracking-wider mb-1">{item.category}</p>
                            <h3 className="text-sm font-medium text-dark dark:text-lightbg line-clamp-2">{item.name}</h3>
                          </div>
                          <button 
                            onClick={() => onRemoveItem(item.id)}
                            className="text-gray-400 hover:text-red-500 transition-colors p-1"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                        <div className="flex justify-between items-end">
                          <div className="flex items-center border border-gray-200 dark:border-gray-700 rounded-md">
                            <button 
                              onClick={() => onUpdateQuantity(item.id, -1)}
                              className="px-2 py-1 text-gray-500 hover:text-dark dark:hover:text-white"
                            >-</button>
                            <span className="px-2 py-1 text-sm text-dark dark:text-lightbg w-8 text-center">{item.quantity}</span>
                            <button 
                              onClick={() => onUpdateQuantity(item.id, 1)}
                              className="px-2 py-1 text-gray-500 hover:text-dark dark:hover:text-white"
                            >+</button>
                          </div>
                          <span className="font-medium text-dark dark:text-lightbg">${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <div className="border-t border-gray-100 dark:border-gray-800 p-6 bg-lightbg/50 dark:bg-dark/50 space-y-6">
                <div className="flex justify-between items-center text-lg">
                  <span className="text-dark/70 dark:text-lightbg/70">Subtotal</span>
                  <span className="font-serif font-semibold text-xl text-dark dark:text-lightbg">${subtotal.toFixed(2)}</span>
                </div>
                <p className="text-xs text-center text-gray-500">Shipping, taxes, and discounts calculated at checkout.</p>
                <div className="space-y-3">
                  <a 
                    href="https://wa.me/263779525675"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full block text-center py-4 rounded-lg bg-[#25D366] hover:bg-[#128C7E] text-white font-medium transition-colors shadow-lg shadow-[#25D366]/20"
                  >
                    Order via WhatsApp
                  </a>
                  <button className="w-full py-4 rounded-lg bg-dark text-white hover:bg-rosegold transition-colors font-medium">
                    Proceed to Checkout
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
