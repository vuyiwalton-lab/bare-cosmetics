import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { faqs } from '../data';
import { Plus, Minus } from 'lucide-react';

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-32 bg-lightbg dark:bg-dark/95">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <span className="text-rosegold font-medium tracking-[0.2em] uppercase text-xs mb-4 block">
            Information
          </span>
          <h2 className="text-4xl md:text-5xl font-serif text-dark dark:text-lightbg mb-6">Frequently Asked Questions</h2>
          <div className="w-16 h-[1px] bg-rosegold mx-auto mb-6" />
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1, ease: "easeOut" }}
              className="border-b border-dark/10 dark:border-white/10"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full flex items-center justify-between py-8 text-left focus:outline-none group"
              >
                <span className={`font-serif text-xl transition-colors ${openIndex === index ? 'text-rosegold' : 'text-dark dark:text-white group-hover:text-rosegold'}`}>
                  {faq.question}
                </span>
                <span className={`shrink-0 transition-transform duration-300 ${openIndex === index ? 'text-rosegold rotate-180' : 'text-dark/40 dark:text-white/40 group-hover:text-rosegold'}`}>
                  {openIndex === index ? <Minus size={20} strokeWidth={1.5} /> : <Plus size={20} strokeWidth={1.5} />}
                </span>
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.4, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="pb-8 text-dark/60 dark:text-lightbg/60 leading-relaxed font-light text-lg">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
