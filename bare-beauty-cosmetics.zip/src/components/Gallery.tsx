import { motion } from 'motion/react';
import { useState } from 'react';
import { Maximize2, X } from 'lucide-react';

const galleryImages = [
  { src: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=1200", title: "Rose Gold Essentials" },
  { src: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&q=80&w=1200", title: "Luxury Accessories" },
  { src: "https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&q=80&w=1200", title: "Hydration Mist" },
  { src: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&q=80&w=1200", title: "Matte Collection" },
  { src: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=1200", title: "Glow Serum" },
  { src: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&q=80&w=1200", title: "Silk Foundation" },
  { src: "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&q=80&w=1200", title: "Signature Scent" },
  { src: "https://images.unsplash.com/photo-1599305090598-fe179d501227?auto=format&fit=crop&q=80&w=1200", title: "Evening Glamour" }
];

export function Gallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section className="py-32 bg-white dark:bg-dark">
      <div className="max-w-[100rem] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <span className="text-rosegold-dark dark:text-rosegold font-medium tracking-[0.3em] uppercase text-xs mb-6 block">
            Portfolio
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-dark dark:text-cream mb-8">The Beauty Experience</h2>
          <div className="w-24 h-[1px] bg-rosegold mx-auto mb-8" />
          <p className="text-dark/60 dark:text-cream/60 max-w-2xl mx-auto font-light text-lg">
            Follow us on Instagram <span className="font-medium text-dark dark:text-white">@barebeauty_by</span> for daily inspiration.
          </p>
        </div>

        <div className="masonry-grid">
          {galleryImages.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.8, delay: (index % 3) * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="masonry-item relative overflow-hidden group cursor-pointer rounded-[2rem] bg-cream dark:bg-charcoal"
              onClick={() => setSelectedImage(item.src)}
            >
              <img
                src={item.src}
                alt={item.title}
                loading="lazy"
                className="w-full object-cover transition-transform duration-[2s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-dark/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] flex flex-col justify-end p-8">
                <div className="transform translate-y-8 group-hover:translate-y-0 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]">
                  <h3 className="text-white font-serif text-2xl mb-2">{item.title}</h3>
                  <div className="w-8 h-[1px] bg-rosegold mb-4" />
                  <div className="w-12 h-12 rounded-full glass !bg-white/20 !border-white/30 flex items-center justify-center text-white backdrop-blur-md">
                    <Maximize2 size={20} strokeWidth={1.5} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-[100] bg-dark/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-10 cursor-zoom-out"
          onClick={() => setSelectedImage(null)}
        >
          <button 
            className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors glass !bg-white/10 !border-white/20 p-4 rounded-full z-50 cursor-pointer hover:rotate-90 duration-300"
            onClick={() => setSelectedImage(null)}
          >
            <X size={24} strokeWidth={1.5} />
          </button>
          <motion.img
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            src={selectedImage}
            alt="Selected full screen"
            className="max-w-full max-h-[90vh] object-contain shadow-2xl rounded-lg cursor-default"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
}
