import { Product, Category, Testimonial, FAQ } from './types';

export const categories: Category[] = [
  { id: '1', name: 'Skincare', icon: 'Sparkles', image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800' },
  { id: '2', name: 'Makeup', icon: 'Brush', image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=800' },
  { id: '3', name: 'Hair Care', icon: 'Scissors', image: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&q=80&w=800' },
  { id: '4', name: 'Fragrances', icon: 'Droplet', image: 'https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&q=80&w=800' },
  { id: '5', name: 'Accessories', icon: 'ShoppingBag', image: 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&q=80&w=800' },
  { id: '6', name: 'Nail Care', icon: 'Palette', image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&q=80&w=800' },
];

export const products: Product[] = [
  {
    id: 'p1',
    name: 'Luminous Glow Serum',
    category: 'Skincare',
    price: 7.99,
    rating: 4.8,
    reviews: 124,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800',
    isNew: true,
  },
  {
    id: 'p2',
    name: 'Velvet Matte Lipstick',
    category: 'Makeup',
    price: 5.50,
    originalPrice: 12.00,
    rating: 4.9,
    reviews: 89,
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&q=80&w=800',
    isSale: true,
  },
  {
    id: 'p3',
    name: 'Hydrating Rose Mist',
    category: 'Skincare',
    price: 6.99,
    rating: 4.7,
    reviews: 56,
    image: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'p4',
    name: 'Midnight Bloom Perfume',
    category: 'Fragrances',
    price: 8.00,
    rating: 5.0,
    reviews: 210,
    image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'p5',
    name: 'Silk Touch Foundation',
    category: 'Makeup',
    price: 7.50,
    rating: 4.6,
    reviews: 178,
    image: 'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'p6',
    name: 'Argan Oil Hair Mask',
    category: 'Hair Care',
    price: 6.00,
    rating: 4.8,
    reviews: 92,
    image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'p7',
    name: 'Rose Gold Brush Set',
    category: 'Accessories',
    price: 7.00,
    originalPrice: 15.00,
    rating: 4.9,
    reviews: 340,
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=800',
    isSale: true,
  },
  {
    id: 'p8',
    name: 'Revitalizing Night Cream',
    category: 'Skincare',
    price: 8.00,
    rating: 4.7,
    reviews: 115,
    image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=800',
    isNew: true,
  }
];

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    name: 'Sarah M.',
    rating: 5,
    text: 'Bare Beauty Cosmetics has completely transformed my skincare routine. Their products feel so luxurious, and the customer service in Bulawayo is unmatched!',
  },
  {
    id: 't2',
    name: 'Chipo N.',
    rating: 5,
    text: 'I absolutely love the Velvet Matte Lipsticks. They last all day and the shades are perfect for my skin tone. Highly recommend!',
  },
  {
    id: 't3',
    name: 'Amanda T.',
    rating: 5,
    text: 'Fast delivery and beautifully packaged. Opening my order felt like receiving a gift. The Hydrating Rose Mist is a game changer.',
  }
];

export const faqs: FAQ[] = [
  {
    question: 'Do you offer wholesale prices?',
    answer: 'Yes, we offer competitive wholesale pricing for bulk orders. Please contact us via WhatsApp or visit our store to discuss wholesale opportunities.'
  },
  {
    question: 'Do you deliver?',
    answer: 'Yes, we offer delivery within Bulawayo and can arrange shipping to other cities across Zimbabwe via reliable courier services.'
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept Cash (USD), EcoCash, Innbucks, and bank transfers. All payments are secure.'
  },
  {
    question: 'Where are you located?',
    answer: 'We are located at Suite 4B, Dansquare Building, Corner 4th Avenue & 5th Avenue, Josiah Tongogara Road, Bulawayo, Zimbabwe.'
  },
  {
    question: 'What are your opening hours?',
    answer: 'We are open Monday to Friday from 8:00 AM to 5:00 PM, Saturday from 8:00 AM to 4:00 PM, and Sunday from 8:00 AM to 5:00 PM.'
  }
];
